#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int MenuInicial(FILE** arquivoDeEntrada);
FILE* abreArquivoRead(char* nomeArquivo);