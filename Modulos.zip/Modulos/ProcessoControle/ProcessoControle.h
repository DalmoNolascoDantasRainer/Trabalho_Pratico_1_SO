#ifndef	PROCESSOCONTROLE_H
#define	PROCESSOCONTROLE_H

#include "../Pipe/Pipe.h"

char controle(FILE* arquivoDeEntrada, int opcao);

#endif